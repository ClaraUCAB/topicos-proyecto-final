import express from "express";
import imageRoutes from "./routes/image.routes";

//Esto crea la aplicacion Express y configura middlewares basicos
const app = express();
app.use(express.json());

// Monta las rutas de  manipulacion de imagenes
app.use("/images", imageRoutes);

// Inicia servidor en puerto 30000
app.listen(3000, () => {
  console.log("Servidor corriendo en http://localhost:3000");
});
